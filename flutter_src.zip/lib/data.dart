import 'dart:io';
import 'package:dio/dio.dart';
import 'package:path/path.dart' as p;
import 'package:mc/dialog_utils.dart';
import 'package:mc/ui_utils.dart';

part 'data_file.dart';

// 프로그램
String get builtinDataPath => 'assets';
String get downloadPath => 'download';
String get currentDirectory => Platform.resolvedExecutable;

// 유틸
String get mcLauncherPath => 'C:/Program Files (x86)/Minecraft Launcher/MinecraftLauncher.exe';
String get javaPath => 'C:/Program Files/Common Files/Oracle/Java/javapath/java.exe';

// 마크
String get appDataPath => Platform.environment['APPDATA']!.replaceAll('\\', '/');
String get minecraftPath => '$appDataPath/.minecraft';

// 프로그램
File get mingVersionChecker => File('$minecraftPath/ming_version');
set mingVersion(String ver) => mingVersionChecker.writeAsStringSync(ver);
String get mingVersion {
  if (mingVersionChecker.existsSync()) return mingVersionChecker.readAsStringSync();
  return 'N/A';
}
