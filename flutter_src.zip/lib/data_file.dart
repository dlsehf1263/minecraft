part of 'data.dart';

//////// 다운로드

const String gitRoot = 'https://github.com/dlsehf1263/minecraft/raw/main';

Future<bool> downloadFileIfNotExist(String file, String url) async {
  if (isDownloaded(file)) return true;
  return downloadFiles([url], saveAs: file);
}

bool isDownloaded(String name) {
  return File('$downloadPath/$name').existsSync();
}

Future<bool> downloadFiles(List<String> urls, {void Function(double)? onProgress, String? saveAs}) async {
  final dio = Dio();

  dio.options.headers.addAll({
    'User-Agent':
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Connection': 'keep-alive',
    'Cache-Control': 'no-cache',
  });

  showSnackBar('다운로드를 시작합니다.');

  try {
    int downloaded = 0;

    for (final url in urls) {
      String filename = url.substring(url.lastIndexOf('/') + 1);
      if (saveAs != null) filename = saveAs;

      await dio.download(
        '$gitRoot/$url',
        '$downloadPath/$filename',
        onReceiveProgress: (received, total) {
          if (total != -1 && onProgress != null) {
            onProgress((downloaded / urls.length + (received / total / urls.length)));
          }
        },
      );

      downloaded++;
    }

    if (onProgress != null) onProgress(1);
  } catch (e) {
    print(e);
    openMessageDialog('오류', '파일 다운로드 오류\n\n$e');
    return false;
  }

  return true;
}

void deleteDownloadCahces() {
  showSnackBar('다운로드 캐시를 제거합니다.');

  final dir = Directory(downloadPath);
  if (dir.existsSync()) dir.deleteSync(recursive: true);
}

Future<String?> getDataFromUrl(String url) async {
  try {
    Response response = await Dio().get(
      '$gitRoot/$url',
      options: Options(
        headers: {'Cache-Control': 'no-cache'},
      ),
    );
    return response.data;
  } catch (e) {
    openMessageDialog('오류', '데이터 가져오기에 실패했습니다.\n\n$e');
    return null;
  }
}

//////// 마크

void copyBasicIfNeed() {
  // 마크 루트 폴더가 없으면 기본 파일 복사
  final mcRoot = File('$minecraftPath/launcher_profiles.json');

  if (!mcRoot.existsSync()) {
    mcRoot.createSync(recursive: true);

    copyFiles(['launcher_profiles.json', 'options.txt'].map((e) => '$builtinDataPath/$e'), minecraftPath);
  }
}

void deleteModeDir() {
  final dir = Directory('$minecraftPath/mods');
  if (dir.existsSync()) dir.deleteSync(recursive: true);
}

void processForgeInstaller(String forgePath) {
  final dir = Directory('forgeinstaller');
  dir.createSync();

  copyFiles([forgePath], dir.path);
  createJavaExecuterBatch('${dir.path}/${p.basenameWithoutExtension(forgePath)}.bat', p.basename(forgePath));

  execute('explorer', [dir.path]);
}

//////// 일반

bool copyFiles(Iterable<String> paths, String dest) {
  try {
    Directory(dest).createSync(recursive: true);

    for (final e in paths) {
      File(e).copySync('$dest/${p.basename(e)}');
    }
  } catch (e) {
    openMessageDialog('오류', '$e');
    return false;
  }

  return true;
}

bool hasFile(String path) {
  return File(path).existsSync();
}

Future<bool> execute(String path, [List<String> argvs = const []]) async {
  showSnackBar('파일을 실행합니다.');

  try {
    Process process = await Process.start(path, argvs);
    return true;
  } catch (e) {
    openMessageDialog('오류', '$e');
    return false;
  }
}

Future<void> createJavaExecuterBatch(String path, String jarPath) async {
  File file = File(path);

  final stream = file.openWrite();
  stream.write('"$javaPath" -jar $jarPath');
  await stream.close();
}

// 이걸로는 포지가 제대로 실행되지 않음.
Future<bool> executeJavaFile(String path) async {
  // execute('java', ['-jar', path]);

  createJavaExecuterBatch('_.bat', path);

  return execute('_.bat');
}
